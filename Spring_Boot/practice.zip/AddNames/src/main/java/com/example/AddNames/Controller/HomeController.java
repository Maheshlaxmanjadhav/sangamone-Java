package com.example.AddNames.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.AddNames.Model.Customer;
import com.example.AddNames.Repository.CustomerRepo;

@Controller
public class HomeController {

	@Autowired
	CustomerRepo customerRepo;
	
	@RequestMapping("/addNames")
	public 	String saveInfoSangamOne(Customer customer)
	{
		customerRepo.save(customer);
		return "home.jsp";
	}
}
