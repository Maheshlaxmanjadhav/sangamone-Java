package com.example.AddNames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AddNamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AddNamesApplication.class, args);
	}

}
