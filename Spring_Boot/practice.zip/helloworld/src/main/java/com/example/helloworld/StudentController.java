package com.example.helloworld;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {
	
	@GetMapping("/std")
	public Student getStudent() {
		return new Student("mahesh","jadhav");
	}
	
	@GetMapping("/std1")
	public List<Student> getStudents(){
		List<Student> students = new ArrayList<>();
		students.add(new Student("ramesh","jadhav"));
		students.add(new Student("mahesh","jadhav"));
		students.add(new Student("sangu","jadhav"));
		students.add(new Student("hera","jadhav"));
		return students;
	}
}
