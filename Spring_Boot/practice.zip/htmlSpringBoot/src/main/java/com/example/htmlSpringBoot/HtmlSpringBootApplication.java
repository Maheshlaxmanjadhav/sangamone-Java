package com.example.htmlSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HtmlSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HtmlSpringBootApplication.class, args);
	}

}
