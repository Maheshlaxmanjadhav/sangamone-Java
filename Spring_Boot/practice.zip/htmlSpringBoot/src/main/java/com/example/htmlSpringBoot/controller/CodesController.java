package com.example.htmlSpringBoot.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.htmlSpringBoot.model.CodeList;

@Controller

@RequestMapping("/code")
public class CodesController {

	
	private List<CodeList> listCodes;
	
	@PostConstruct
	private void loadData()
	{
		CodeList cod1=new CodeList(1,"#FEE2E2");
		CodeList cod2=new CodeList(2,"#FEE2E3");
		CodeList cod3=new CodeList(1,"#FEE2E4");
		CodeList cod4=new CodeList(2,"#FEE2E5");
		
		listCodes=new ArrayList();
		
		listCodes.add(cod1);
		listCodes.add(cod2);
		listCodes.add(cod3);
		listCodes.add(cod4);
	}
	
	@GetMapping("/list")
	public String showCodes(Model model)
	{
		model.addAttribute("codes",listCodes);
		return "color";
		
	}
}
