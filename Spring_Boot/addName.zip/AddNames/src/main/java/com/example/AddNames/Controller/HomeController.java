package com.example.AddNames.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.AddNames.Model.Customer;
import com.example.AddNames.Repository.CustomerRepo;

@Controller
public class HomeController {
	
	@Autowired
	CustomerRepo repo;
	
	@RequestMapping("/")
	public String InfoSangamOne(Customer customer1){
		return "home";
	}
	
	@RequestMapping("/saveData")
	@ResponseBody
	public String saveInfoSangamOne(Customer customer1) {
		
		repo.save(customer1);
		return "Success";
	}
	
	
}
