package com.example.AddNames.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.AddNames.Model.Customer;

public interface CustomerRepo extends JpaRepository<Customer, Integer>{

}