package com.example.AddNames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddNamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
