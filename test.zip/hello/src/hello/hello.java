package hello;

public class hello {
	public static void main(String[] args) {
		//hello world
		System.out.println("hello world");
		
		//Create a variable called name of type String and assign it the value "John"
		String name="John";
		System.out.println(name);
		
		//Create a variable called myNum of type int and assign it the value 15
		int myNum=15;
		System.out.println(myNum);
		
		//Create a variable named carName and assign the value Volvo to it.
		String carName="Volvo";
		System.out.println(carName);
		
		//Create a variable named maxSpeed and assign the value 120 to it.
		int maxSpeed=120;
		System.out.println(maxSpeed);
		
		//Display the sum of 5 + 10, using two variables: x and y.
		int x=5,y=10;
		System.out.println(x+y);
		
		//Create a variable called z, assign x + y to it, and display the result.
		int z;
		z=x+y;
		System.out.println(z);
		
		//create three variables of the same type, using a comma-separated list
		int s,m,n;
		s=51;
		m=10;
		n=s+m;
		System.out.println(n);
		
		//Multiply 10 with 5, and print the result.
		int mul=10*5;
		System.out.println(mul);
		
		//Divide 10 by 5, and print the result.
		int div=10/5;
		System.out.println(div);
		
		//Use the correct operator to increase the value of the variable x by 1.
		int inc=1;
		++inc;
		System.out.println(inc);
		
        //Use the addition assignment operator to add the value 5 to the variable x.
		int p=1;
		p +=5;
		System.out.println(p);
		
		//Create a variable of type String and assign it a value
		String str="mahesh";
		System.out.println(str);
		
		//create a greeting variable of type String and assign it the value Hello
		String greeting="hello";
		System.out.println(greeting);
		
		//Use the correct method to print the length of the txt string
		System.out.println(greeting.length());
		
		//Convert the value of txt to upper case.
		System.out.println(greeting.toUpperCase());
		
		//Use the correct operator to concatenate two strings
		String fname="mahesh";
		String lname="jadhav";
		System.out.println(fname+lname);
		
		//Use the correct method to concatenate two strings
		System.out.println(fname.concat(lname));
		
		//Return the index (position) of the first occurrence of "e" in the following string
		System.out.println(greeting.indexOf("e"));
		
	}
}
